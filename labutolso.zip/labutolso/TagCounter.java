package src;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class TagCounter extends DefaultHandler {
	public Map<String, Integer> m = new HashMap<String, Integer>();
	static double lat2=0;
	static double lon2=0;
	
	public static void main(String[] args){
	
		if(args.length>2){
		lat2=Double.parseDouble(args[3]);
		lon2=Double.parseDouble(args[5]);
		}
		
		DefaultHandler h = new TagCounter();
		SAXParserFactory factory = SAXParserFactory.newInstance();
		 try{
			 SAXParser p = factory.newSAXParser();
			 p.parse(new File(args[1]), h);
			 

		 }	catch (Exception e){
			 e.printStackTrace();
		 }
		 	
		 ((TagCounter) h).println();
		 System.out.println("");
		 
		 
		 ((TagCounter) h).sortedPrint();
		 
		
	 }
	
	public void sortedPrint(){
		Collections.sort(megallo, new myComparator());
		for(BusStop b:megallo)
			System.out.println(b);
	}
	public void println(){
		for(Map.Entry<String, Integer> e : m.entrySet()){
			System.out.println(e);
		}
	}
	
	ArrayList<BusStop> megallo = new ArrayList<BusStop>();
	BusStop tmp=new BusStop();
	
	@Override
	public void startElement(String namespaceUri,String sName, String qName, Attributes attributes) throws SAXException{
		if(m.get(qName)==null){
			m.put(qName, 1);
		}
		else {
			Integer tmp = m.get(qName)+1;
			m.put(qName, tmp);
		}
		
		
		if(qName.equals("node")){
			tmp=new BusStop();
			double lat=Double.parseDouble(attributes.getValue("lat"));
			double lon=Double.parseDouble(attributes.getValue("lon"));
			tmp.distance=dist1(lat, lon, lat2, lon2);
		}	
		if(qName.equals("tag")){
			if(attributes.getValue("v").equals("bus_stop")){
				tmp.valid=true;
			}
			if(attributes.getValue("k").equals("name")) 
					tmp.name=attributes.getValue("v");
			else if(attributes.getValue("k").equals("old_name"))
					tmp.oldName=attributes.getValue("v");
			else if(attributes.getValue("k").equals("wheelchair"))
					tmp.wheelchair=attributes.getValue("v");
			
		}	
		
		}
	@Override
	public void endElement(String namespaceUri,String sName, String qName) throws SAXException{
		if(qName.equals("node") &&  tmp.valid){
			megallo.add(tmp);
		}
	}
	
	
	double dist1(double lat1, double lon1, double lat2, double lon2) {
		double R = 6371000; // metres
		double phi1 = Math.toRadians(lat1);
		double phi2 = Math.toRadians(lat2);
		double dphi = phi2-phi1;
		double dl = Math.toRadians(lon2-lon1);
		double a = Math.sin(dphi/2) * Math.sin(dphi/2) +
		Math.cos(phi1) * Math.cos(phi2) *
		Math.sin(dl/2) * Math.sin(dl/2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
		double d = R * c;
		return d;
		}
}

class BusStop{
	public boolean valid;
	public String name;
	public String oldName;
	public String wheelchair;
	double distance;
	
	BusStop(){
		valid=false;
	}
	
	@Override
	public String toString(){
		String myEol = System.getProperty("line.separator");  
	       return String.format( "Meg�ll�:" + myEol +  "	N�v: " + name + " (" + oldName+ ")" + myEol +"	Kerekessz�k: "+ wheelchair + myEol + "	T�vols�g: " + distance);

	}
	
}

class myComparator implements Comparator<BusStop> {

	@Override
	public int compare(BusStop o1, BusStop o2) {
		if (o1.distance < o2.distance)
			return 1;
		else if (o1.distance > o2.distance)
			return -1;
		else
			return 0;
	}

}

