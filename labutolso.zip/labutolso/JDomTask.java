package src;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;


public class JDomTask {
	

	public static Map<String, Integer> m = new HashMap<String, Integer>();
	
	public static void main(String[] args){
		
		SAXBuilder b = new SAXBuilder();
		File f = new File(args[1]);

		try{
			Document doc = (Document)b.build(f);
			Element r = doc.getRootElement();	
			int db=0;
			
			
	
			count(r, "");
			
			for(Map.Entry<String, Integer> e : m.entrySet()){
				db+=e.getValue();}
				System.out.println(db);
		
		}catch (IOException io){
			System.out.println(io.getMessage());
		}catch (JDOMException je){
			System.out.println(je.getMessage());
		}
	}
	

	
	static void count(Element n, String tab){
		
		if(m.get(n.getName())==null){
			m.put(n.getName(), 1);
		}
		else {
			Integer tmp = m.get(n.getName())+1;
			m.put(n.getName(), tmp);
		}
		
		List<Element> nl = n.getChildren();
	
		for (Element e1 : nl) {
			count(e1, tab+" ");
		}
	}
}

