package beer;

import java.io.Serializable;

public class Beer implements Serializable {

    private String name;
    private String style;
    private double strength;

    public Beer(String name, String style, double strength) {
        this.name = name;
        this. style = style;
        this.strength = strength;
    }

    public String getName() {
        return name;
    }

    public String getStyle() {
        return style;
    }

    public double getStrength() {
        return strength;
    }

    public void print() {
        System.out.println("name: " + name);
        System.out.println("style: " + style);
        System.out.println("strength: " + strength);
    }
}
