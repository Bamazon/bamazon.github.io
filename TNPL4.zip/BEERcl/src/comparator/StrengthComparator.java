package comparator;
import beer.Beer;
import java.util.Comparator;

public class StrengthComparator implements java.util.Comparator<Beer> {

    public int compare(Beer b1, Beer b2) {
        return Double.valueOf(b1.getStrength()).compareTo(b2.getStrength());
    }

}
