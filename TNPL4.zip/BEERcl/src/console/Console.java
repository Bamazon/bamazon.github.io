package console;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import beer.Beer;
import comparator.NameComparator;
import comparator.StrengthComparator;
import comparator.StyleComparator;

public class Console {
    protected java.util.List<Beer> beers = new ArrayList<Beer>();

    public void start() {
        try {

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            String line = br.readLine();
            String[] cmd = line.split("\\s+");
            while (!cmd[0].equals("exit")) {
                if (cmd[0].equals("add"))
                    add(cmd);
                else if (cmd[0].equals("list"))
                    list(cmd);
                else if (cmd[0].equals("load"))
                    load(cmd);
                else if (cmd[0].equals("save"))
                    save(cmd);
                else if (cmd[0].equals("delete"))
                    delete(cmd);
                line = br.readLine();
                cmd = line.split("\\s+");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void add(String[] cmd) {
        beers.add(new Beer(cmd[1], cmd[2], Double.parseDouble(cmd[3])));
    }

    protected void list(String[] cmd) {
        List<Beer> temp = new ArrayList<Beer>(beers);

        if (cmd.length >= 2) {
            if (cmd[1].equals("name")) {
                temp.sort(new NameComparator());
            } else if (cmd[1].equals("style")) {
                temp.sort(new StyleComparator());
            } else if (cmd[1].equals("strength")) {
                temp.sort(new StrengthComparator());
            }
        }

        for (Beer b : temp)
            b.print();
    }

    protected void load (String[] cmd) {
        try {
            ObjectInputStream o = new ObjectInputStream(new FileInputStream(new File(cmd[1])));
            beers = (List<Beer>)o.readObject();
            o.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void save (String[] cmd) {
        try {
            ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(new File(cmd[1])));
            o.writeObject(beers);
            o.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void delete (String[] cmd) {
        int idx = Collections.binarySearch(beers, new Beer(cmd[1], "", 0), new NameComparator());
        if (idx >= 0)
            beers.remove(idx);
        else
            System.out.println("Beer not found.");
    }
}

