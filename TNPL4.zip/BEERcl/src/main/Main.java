package main;
import console.Console;

public class Main {

    public static void main(String[] args) {
        Console c = new Console();
        c.start();
    }
}
