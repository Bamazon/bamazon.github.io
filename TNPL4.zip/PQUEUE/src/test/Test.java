package test;
import pqueue.PQueue;
import exception.EmptyQueueException;

public class Test {

    public static void main(String[] args) {
        try {
            PQueue pq = new PQueue<String>();
            pq.push("Cheese");
            pq.push("Milk");
            pq.push("Hamburger");
            System.out.println(pq.top());
            System.out.println(pq.pop());
            System.out.println(pq.top());
            System.out.println(pq.size());
            pq.clear();
            System.out.println(pq.size());
            System.out.println(pq.pop());

        } catch (EmptyQueueException e) {
            System.out.println("Queue is empty.");
        }

        PQueue<Integer> s = new PQueue<Integer>();
        s.push(1); s.push(2); s.push(3); s.push(4);
        for (Integer i : s) {
            System.out.println(i);
        }

    }
}
