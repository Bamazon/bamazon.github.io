package pqueue;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import exception.EmptyQueueException;


public class PQueue<T extends Comparable> implements Iterable<T>{
    List<T> data = new ArrayList<T>();

    public void push(T t) {
        data.add(t);
    }

    public T top() {
        return (T)Collections.max(data);
    }

    public T pop() throws EmptyQueueException{
        if (size() == 0)
            throw new EmptyQueueException();
        T t = top();
        data.remove(t);
        return t;

    }

    public int size() {
        return data.size();
    }

    public void clear() {
        data.clear();
    }

    public Iterator<T> iterator() {
        return data.iterator();
    }


}
