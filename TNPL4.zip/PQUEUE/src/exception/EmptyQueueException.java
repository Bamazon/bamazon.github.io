package exception;

public class EmptyQueueException extends Exception{

}
