/**
 * 
 */
/**
 * @author Csiga
 *
 */
module helloworld {
}