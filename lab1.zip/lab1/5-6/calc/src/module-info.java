/**
 * 
 */
/**
 * @author Csiga
 *
 */
module calc {
}