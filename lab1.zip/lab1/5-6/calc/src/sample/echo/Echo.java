package sample.echo;

public class Echo {
	public int number(int a) {
		return a;
	}
}