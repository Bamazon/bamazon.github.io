package swingmvclab;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;

/*
 * A megjelen�tend� ablakunk oszt�lya.
 */
public class StudentFrame extends JFrame {

    class StudentTableCellRenderer implements TableCellRenderer {

        private TableCellRenderer renderer;

        public StudentTableCellRenderer(TableCellRenderer defRenderer) {
            this.renderer = defRenderer;
        }
        @Override
        public Component getTableCellRendererComponent(JTable table,
                                                       Object value, boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            Component component = renderer.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, column);

            if ((Boolean)data.getValueAt(row, 2) && (Integer)data.getValueAt(row, 3) >= 2)
                component.setBackground(Color.green);
            else
                component.setBackground(Color.red);

            return component;
        }
    }


    /*
     * Ebben az objektumban vannak a hallgat�i adatok.
     * A program indul�s ut�n bet�lti az adatokat f�jlb�l, bez�r�skor pedig kimenti oda.
     * 
     * NE M�DOS�TSD!
     */
    private StudentData data;
    
    /*
     * Itt hozzuk l�tre �s adjuk hozz� az ablakunkhoz a k�l�nb�z� komponenseket
     * (t�bl�zat, beviteli mez�, gomb).
     */
    private void initComponents() {
        this.setLayout(new BorderLayout());
        JTable jTable = new JTable(data);
        JScrollPane jScrollPane = new JScrollPane(jTable);
        jTable.setFillsViewportHeight(true);
        jTable.setRowSorter(new TableRowSorter<StudentData>(data));
        jTable.setDefaultRenderer(String.class, new StudentTableCellRenderer(jTable.getDefaultRenderer(String.class)));
        jTable.setDefaultRenderer(Boolean.class, new StudentTableCellRenderer(jTable.getDefaultRenderer(Boolean.class)));
        jTable.setDefaultRenderer(Integer.class, new StudentTableCellRenderer(jTable.getDefaultRenderer(Integer.class)));
        JTextField nameField = new JTextField();
        nameField.setColumns(20);
        JLabel nameLabel = new JLabel("N�v:");
        JTextField neptunField = new JTextField();
        neptunField.setColumns(6);
        JLabel neptunLabel = new JLabel("Neptun");
        JButton button = new JButton("Felvesz");
        JPanel inputPanel = new JPanel();
        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(neptunLabel);
        inputPanel.add(neptunField);
        inputPanel.add(button);
        this.add(jScrollPane, BorderLayout.CENTER);
        this.add(inputPanel, BorderLayout.SOUTH);

        button.addActionListener( (e) -> {

            data.addStudent(nameField.getText(), neptunField.getText());

        });
    }

    /*
     * Az ablak konstruktora.
     * 
     * NE M�DOS�TSD!
     */
    @SuppressWarnings("unchecked")
    public StudentFrame() {
        super("Hallgat�i nyilv�ntart�s");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Indul�skor bet�ltj�k az adatokat
        try {
            data = new StudentData();
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"));
            data.students = (List<Student>)ois.readObject();
            ois.close();
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        
        // Bez�r�skor mentj�k az adatokat
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"));
                    oos.writeObject(data.students);
                    oos.close();
                } catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Fel�p�tj�k az ablakot
        setMinimumSize(new Dimension(500, 200));
        initComponents();
    }

    /*
     * A program bel�p�si pontja.
     * 
     * NE M�DOS�TSD!
     */
    public static void main(String[] args) {
        // Megjelen�tj�k az ablakot
        StudentFrame sf = new StudentFrame();
        sf.setVisible(true);
    }
}
