package junitlab.bank;

import junitlab.bank.AccountNotExistsException;
import junitlab.bank.impl.FirstNationalBank;
import junitlab.bank.impl.GreatSavingsBank;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class BankTest {

    Bank bank;

    @Before
    public void setUp() {
        bank = new GreatSavingsBank();
    }

    @Test
    public void testOpenAccount() throws Exception{
        String testAcc = bank.openAccount();
        assertEquals(bank.getBalance(testAcc),0,0);
    }

    @Test
    public void testUniqueAccount(){
        String testAcc1 = bank.openAccount();
        String testAcc2 = bank.openAccount();
        assertNotEquals(testAcc1, testAcc2,0);
    }

    @Test(expected=AccountNotExistsException.class)
    public void testInvalidAccount() throws Exception{
        bank.getBalance("G�za");
    }

    @Test
    public void testDeposit() throws Exception{
        String testAcc = bank.openAccount();
        bank.deposit(testAcc, 2000);
        assertEquals(bank.getBalance(testAcc), 2000,0);
    }

}
