package junitlab.bank;

import junitlab.bank.impl.GreatSavingsBank;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BankTestFixture {

    Bank bank;
    String testAcc1;
    String testAcc2;

    @Before
    public void setUp() throws Exception{
        bank = new GreatSavingsBank();
        testAcc1 = bank.openAccount();
        bank.deposit(testAcc1, 1500);
        testAcc2 = bank.openAccount();
        bank.deposit(testAcc2, 12000);
    }

    @Test
    public void testTransfer() throws Exception{
        bank.transfer(testAcc2, testAcc1, 3456);
        assertEquals(bank.getBalance(testAcc1), 4956);
        assertEquals(bank.getBalance(testAcc2), 8544);
    }

    @Test(expected = NotEnoughFundsException.class)
    public void testTransferWithoutEnoughFounds() throws Exception{
        bank.transfer(testAcc1, testAcc2, 3456);
    }

}
