package main;

import javafx.geometry.HorizontalDirection;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

public class CaesarFrame extends JFrame {

    private class OkButtonActionListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            outputField.setText(caesarCode(inputField.getText(), (char)offsetSelector.getSelectedItem()));
        }

    }

    /*
    private class InputFieldKeyListener implements KeyListener {

        public void keyPressed(KeyEvent e) {
        }

        public void keyReleased(KeyEvent e) {
        }

        public void keyTyped(KeyEvent e) {
            outputField.setText(caesarCode(inputField.getText(), (char)offsetSelector.getSelectedItem()));
        }

    }
    */

    private class InputFieldDocumentListener implements DocumentListener {

        public void changedUpdate(DocumentEvent e) {
        }

        public void insertUpdate(DocumentEvent e) {
            outputField.setText(caesarCode(inputField.getText(), (char)offsetSelector.getSelectedItem()));
        }

        public void removeUpdate(DocumentEvent e) {
            outputField.setText(caesarCode(inputField.getText(), (char)offsetSelector.getSelectedItem()));
        }

    }

    JComboBox offsetSelector;
    JTextField inputField;
    JButton code;
    JTextField outputField;
    JLabel outputLabel;

    JPanel upperPanel;
    JPanel lowerPanel;

    public CaesarFrame() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("SwingLab");
        setSize(400, 110);
        setResizable(false);

        ArrayList<Character> letters = new ArrayList<Character>();
        for (int i = 0; i <= 'Z' - 'A'; ++i)
            letters.add((char)(i + 'A'));
        offsetSelector = new JComboBox(letters.toArray());
        inputField = new JTextField();
        inputField.setColumns(20);
        //inputField.addKeyListener(new InputFieldKeyListener());
        inputField.getDocument().addDocumentListener(new InputFieldDocumentListener());
        code = new JButton("Code!");
        code.addActionListener(new OkButtonActionListener());
        outputLabel = new JLabel("Output:");
        outputField = new JTextField();
        outputField.setColumns(20);
        outputField.setEnabled(false);


        upperPanel = new JPanel();
        upperPanel.add(offsetSelector);
        upperPanel.add(inputField);
        upperPanel.add(code);
        lowerPanel = new JPanel();
        lowerPanel.add(outputLabel);
        lowerPanel.add(outputField);

        setLayout(new BoxLayout(getContentPane(),  BoxLayout.Y_AXIS));
        add(upperPanel);
        add(lowerPanel);
    }

    public String caesarCode(String input, char offset) {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < input.length(); ++i) {

            char temp = (char)(input.charAt(i) + offset - 'A');
            if (temp > 'Z')
                temp -= 'Z' - 'A' + 1;

            output = output.append(temp);
        }
        return output.toString();
    }

}
