package main;

public class Main {

    public static void main(String[] args) {

        String s1 = "ALMAFA";
        String s2 = "KROKODIL";

        CaesarFrame c = new CaesarFrame();

        System.out.println(s1);
        System.out.println(c.caesarCode(s1, 'F'));
        System.out.println(s2);
        System.out.println(c.caesarCode(s2, 'M'));

        CaesarFrame cf = new CaesarFrame();
        cf.setVisible(true);

    }

}
