package swingmvclab;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
 * A megjelen�tend� ablakunk oszt�lya.
 */
public class StudentFrame extends JFrame {
    
    /*
     * Ebben az objektumban vannak a hallgat�i adatok.
     * A program indul�s ut�n bet�lti az adatokat f�jlb�l, bez�r�skor pedig kimenti oda.
     * 
     * NE M�DOS�TSD!
     */
    private StudentData data;
    
    /*
     * Itt hozzuk l�tre �s adjuk hozz� az ablakunkhoz a k�l�nb�z� komponenseket
     * (t�bl�zat, beviteli mez�, gomb).
     */
    
    
    
    private class Clicklistener implements ActionListener {
    	
    	private JTextField nameField, neptunField;
    	private StudentData data;
    	
    	public Clicklistener(JTextField nameField, JTextField neptunField, StudentData data) {
    		this.nameField = nameField;
    		this.neptunField = neptunField;
    		this.data = data;
    	}
    	
		@Override
		public void actionPerformed(ActionEvent e) {
			data.addStudent(nameField.getText(), neptunField.getText());
			
		}
    	
    }
    
    
    private void initComponents() {
        this.setLayout(new BorderLayout());
        
        
        JTable tabla = new JTable(data);
        JScrollPane jsp = new JScrollPane(tabla);
        jsp.setVisible(true);
        tabla.setFillsViewportHeight(true);
        this.add(jsp,BorderLayout.CENTER);
        
        
        JPanel p2 = new JPanel(new FlowLayout());
        this.add(p2, BorderLayout.SOUTH);
        JTextField nameField = new JTextField(20);
        JTextField neptunField = new JTextField(6);
        JButton btn = new JButton("Felvesz");
        p2.add(nameField);
        p2.add(neptunField);
        p2.add(btn);
        btn.addActionListener(new Clicklistener(nameField, neptunField, data));
        
        // ...
    }

    /*
     * Az ablak konstruktora.
     * 
     * NE M�DOS�TSD!
     */
    @SuppressWarnings("unchecked")
    public StudentFrame() {
        super("Hallgat�i nyilv�ntart�s");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Indul�skor bet�ltj�k az adatokat
        try {
            data = new StudentData();
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"));
            data.students = (List<Student>)ois.readObject();
            ois.close();
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        
        // Bez�r�skor mentj�k az adatokat
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"));
                    oos.writeObject(data.students);
                    oos.close();
                } catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Fel�p�tj�k az ablakot
        setMinimumSize(new Dimension(500, 200));
        initComponents();
    }

    /*
     * A program bel�p�si pontja.
     * 
     * NE M�DOS�TSD!
     */
    public static void main(String[] args) {
        // Megjelen�tj�k az ablakot
        StudentFrame sf = new StudentFrame();
        sf.setVisible(true);
    }
}
