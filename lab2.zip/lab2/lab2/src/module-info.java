/**
 * 
 */
/**
 * @author Csiga
 *
 */
module lab2 {
}