package sample;

public class Asztal {
	private Jatekos[] jatekos;
	private double tet;
	private int kor;

	public Asztal() {
		jatekos = new Jatekos[0];
	}

	public void ujJatek() {
		tet = 0;
		kor = 0;
	}

	public void addJatekos(Jatekos j) throws NincsJatekos {
		if (jatekos.length == 10) {
			throw new NincsJatekos("Az asztal tele van.");
		}
		else {
			Jatekos[] temp;
			temp = jatekos;
			jatekos = new Jatekos[temp.length+1];
			
			for(int i = 0;i<temp.length;i++) {
				jatekos[i] = temp[i];
			}
			
			j.setAsztal(this);
			jatekos[jatekos.length-1] = j;
		}
	}

	public int getKor() {
		return kor;
	}

	public void emel(double d) {
		tet += d;
	}

	public void kor() throws NincsJatekos {
		if (jatekos.length==0)
			throw new NincsJatekos("Nincs j�t�kos");
		
		for (int i = 0; i < jatekos.length; i++) {
			jatekos[i].lep();
			System.out.println("lepett");
		}
		kor++;
		System.out.println("A t�t �rt�ke: " + tet);
	}
}
