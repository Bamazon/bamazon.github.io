package sample;

public class NincsJatekos extends Exception {
	public NincsJatekos(String msg) {
		super(msg);
	}
}
