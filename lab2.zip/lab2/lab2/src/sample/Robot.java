package sample;

public class Robot extends Jatekos {
	
	
	public void lep() {
		System.out.println(toString() + " " + id + " " + asztal.getKor() + ". k�r");
	}
	
	public String toString() {
		return "Robot";
	}
}
