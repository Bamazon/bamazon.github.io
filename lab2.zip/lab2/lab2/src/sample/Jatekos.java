package sample;

public class Jatekos {
	
	protected Asztal asztal = new Asztal();
	private static int jatekosId = 1;
	protected int id;
	
	Jatekos() {
		id = jatekosId;
		jatekosId++;
	}
	
	public void lep() {
		
	}
	
	public void setAsztal(Asztal a){
		this.asztal = a;
	}
	
	public void finalize() {
		System.out.println(id + " " + toString());
	}
	
	
}
