package sample;

public class Main {
	public static void main(String[] args) {
		Asztal asztal1 = new Asztal();

		Kezdo jatekos1 = new Kezdo();
		Kezdo jatekos2 = new Kezdo();
		Robot jatekos3 = new Robot();

		try {
			asztal1.addJatekos(jatekos1);
			asztal1.addJatekos(jatekos2);
			asztal1.addJatekos(jatekos3);

			asztal1.ujJatek();
			for (int i = 0; i < 3; i++) {
				asztal1.kor();
				System.out.println("A k�r�k sz�ma: " + asztal1.getKor());
			}
		} catch (Exception kivetel) {
			System.out.println(kivetel);
		}

		
		
		
		
		Asztal asztal2 = new Asztal();
		try {
			asztal2.kor();
		} catch (Exception kivetel) {
			System.out.println(kivetel);
		}
		
		asztal1 = null;
		System.gc();
	}
}
